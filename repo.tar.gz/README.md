# Capstone
Capstone Project

This is for my capstone project at Maryville University. It is an app called Stonedex that allows you to view semi precious stones and eithor add them to a wish list or add them to your inventory to keep track of.
I hope this app helps any stone collectors out there.
